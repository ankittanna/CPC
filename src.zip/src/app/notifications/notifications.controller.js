'use strict';

angular.module('cpccore')
  .controller('NotificationsCtrl', function($scope, $window, $state, $location,$stateParams,objectStore) {
});

'use strict';

angular.module('cpccore')
  .controller('ConversationPDFCtrl', function($scope, $window, $state, $location,$stateParams,objectStore) {
});

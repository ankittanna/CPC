'use strict';

angular.module('cpccore')
  .controller('FeedbackPDFTeamCtrl', function($scope, $window, $state, $location,$stateParams,objectStore) {
});

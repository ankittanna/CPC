'use strict';

angular.module('cpccore')
  .controller('FeedbackPDFCtrl', function($scope, $window, $state, $location,$stateParams,objectStore) {
});

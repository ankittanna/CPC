'use strict';

angular.module('cpccore')
  .controller('ConvDetCtrl', function($scope,$state) {

  });

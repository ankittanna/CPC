'use strict';

angular.module('cpccore')
  .controller('ConversationPDFTeamCtrl', function($scope, $window, $state, $location,$stateParams,objectStore,localStorageService) {
});
